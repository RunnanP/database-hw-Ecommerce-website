package com.cse305.Service;

import com.cse305.Entity.Shipment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class ShipmentService {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    private char[] trackChar= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N',
            'O','P','Q','R','S','T','U','V','W','X','Y','Z'};

    public boolean checkOrderExistById(String id){
        if (this.getShipmentByTrackingNumber(id) == null){
            return false;
        }else
            return true;

    }
    public    String generate_trackingNum(){
        String orderID ="";
       // do {
            for (int i = 0; i < 9; i++) {
                orderID += trackChar[(int) (Math.random() * 36)];
            }
        //}while(checkOrderExistById(orderID));
        return orderID;
    }
    public int insertShipment(Shipment shipment){
        return jdbcTemplate.update("insert into shipment(TrackingNumber,Address,ShipmentCharge,TypeOfShipment) values(?,?,?,?)"
                ,shipment.getTrackingNumber(),shipment.getAddress(),shipment.getShipmentCharge(),shipment.getTypeOfShipment());
    }

    public int deleteShipmentByTrackingNumber(String id) {
        return jdbcTemplate.update("delete from shipment where TrackingNumber=?" ,id );
    }

    public int updateShipment(Shipment shipment){
        return deleteShipmentByTrackingNumber(shipment.getTrackingNumber()) + insertShipment(shipment);
    }

    public void deleteAllShipment(){

        jdbcTemplate.update("delete * from shipment");
    }

    public List<Shipment> getAllShipment(){

        List rows=jdbcTemplate.queryForList("select * from shipment");
        Iterator it=rows.iterator();
        List<Shipment> ShipmentList=new ArrayList<>();
        Shipment tempShipment=null;
        while(it.hasNext()){
            Map shipmentMap=(Map)it.next();
            tempShipment=new Shipment();
            String tTracking=shipmentMap.get("TrackingNumber")+"";
            String tAdd=shipmentMap.get("Address")+"";
            double tChagrge=Double.parseDouble(shipmentMap.get("ShipmentCharge")+"");
            String tType=shipmentMap.get("TypeOfShipment")+"";

            tempShipment.setTrackingNumber(tTracking);
            tempShipment.setAddress(tAdd);
            tempShipment.setShipmentCharge(tChagrge);
            tempShipment.setTypeOfShipment(tType);

            ShipmentList.add(tempShipment);

        }
        return ShipmentList;
    }
    public int getShipmentQuantity(){
        return getAllShipment().size();
    }

    public Shipment getShipmentByTrackingNumber(String trackingNumber) {
        List rows=jdbcTemplate.queryForList("select * from shipment where TrackingNumber = ?",trackingNumber);
        if (rows.size() == 0){
            return null;
        }else {
            Map shipmentMap=(Map)rows.get(0);
            Shipment tempShipment=null;
            tempShipment=new Shipment();
            String tTracking=shipmentMap.get("TrackingNumber")+"";
            String tAdd=shipmentMap.get("Address")+"";
            double tChagrge=Double.parseDouble(shipmentMap.get("ShipmentCharge")+"");
            String tType=shipmentMap.get("TypeOfShipment")+"";
            tempShipment.setTrackingNumber(tTracking);
            tempShipment.setAddress(tAdd);
            tempShipment.setShipmentCharge(tChagrge);
            tempShipment.setTypeOfShipment(tType);
            return tempShipment;
        }



    }
}
