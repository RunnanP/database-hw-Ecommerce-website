package com.cse305.Service;


import com.cse305.Entity.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class UsersService{

    @Autowired
    private JdbcTemplate jdbcTemplate;




    public int insertUsers(Users users) {
        return jdbcTemplate.update("insert into users(UserId,Role) values(?,?)",users.getUserId(),users.getRole());
    }
    /*public void insertUsers(Users users) {
        jdbcTemplate.update("insert into users(UserId,Role) values(?,?)",users.getUserId(),users.getRole());
    }*/


    public int deleteUsersById(String id) {
        //jdbcTemplate.update("delete from users where UserID=123");
      //  jdbcTemplate.update("delete from users where UserID=\"" +id+"\"" );

        return jdbcTemplate.update("delete from users where UserID=?" ,id );
    }


    public int updateUsers(Users users){
        return deleteUsersById(users.getUserId()) + insertUsers(users);

    }


    public void deleteAllUsers(){

        jdbcTemplate.update("delete * from users");
    }



    public List<Users> getAllUser(){

        List rows=jdbcTemplate.queryForList("select * from users");
        Iterator it=rows.iterator();
        List<Users> usersList=new ArrayList<>();
        Users tempUser=null;
        while(it.hasNext()){
            Map userMap=(Map)it.next();
            tempUser=new Users();
            String tempUserid=userMap.get("UserID")+"";
            String temprole=userMap.get("Role")+"";
            tempUser.setUserId(tempUserid);
            tempUser.setRole(temprole);
            usersList.add(tempUser);

        }
        return usersList;
    }

    public int getUsersQuantity(){
        return this.getAllUser().size();
    }

    public Users getUsersById(String id) {
        List rows=jdbcTemplate.queryForList("select * from users where UserID = ?",id);
        if(rows.size()==0){
            return null;
        }else{
            Map userMap=(Map)rows.get(0);
            Users tempUser=new Users();
            tempUser.setUserId(userMap.get("UserID")+"");
            tempUser.setRole(userMap.get("Role")+"");
            return tempUser;
        }


    }
}
