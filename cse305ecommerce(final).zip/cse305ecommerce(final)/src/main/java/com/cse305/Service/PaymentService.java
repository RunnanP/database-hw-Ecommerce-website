package com.cse305.Service;

import com.cse305.Entity.Payment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class PaymentService {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private char[] payChar= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N',
            'O','P','Q','R','S','T','U','V','W','X','Y','Z'};

    public boolean checkOrderExistById(String id){
        if (this.getPaymentByPaymentId(id) == null){
            return false;
        }else
            return true;

    }
    public    String generate_paymentID(){
        String orderID ="";
        //do {
            for (int i = 0; i < 9; i++) {
                orderID += payChar[(int) (Math.random() * 36)];
            }
        //}while(checkOrderExistById(orderID));
        return orderID;
    }
    public int insertPayment(Payment payment){
        return jdbcTemplate.update("insert into payment(PaymentID,CardNumber,PaymentType) values(?,?,?)"
                ,payment.getPaymentID(),payment.getCardNumber(),payment.getPaymentType());
    }

    public int deletePaymentById(String id) {
        return jdbcTemplate.update("delete from payment where PaymentID=?" ,id );
    }

    public int updatePayment(Payment payment){
        return deletePaymentById(payment.getPaymentID())+insertPayment(payment);
    }

    public void deleteAllPayment(){

        jdbcTemplate.update("delete * from payment");
    }

    public List<Payment> getAllPayment(){

        List rows=jdbcTemplate.queryForList("select * from payment");
        Iterator it=rows.iterator();
        List<Payment> PaymentList=new ArrayList<>();
        Payment tempPayment=null;
        while(it.hasNext()){
            Map paymentMap=(Map)it.next();
            tempPayment=new Payment();

            String tID=paymentMap.get("PaymentID")+"";
            String tCard=paymentMap.get("CardNumber")+"";
            String tType=paymentMap.get("PaymentType")+"";

            tempPayment.setPaymentID(tID);
            tempPayment.setCardNumber(tCard);
            tempPayment.setPaymentType(tType);

            PaymentList.add(tempPayment);

        }
        return PaymentList;
    }
    public int getPaymentQuantity(){
        return getAllPayment().size();
    }

    public Payment getPaymentByPaymentId(String paymentID) {
        List rows=jdbcTemplate.queryForList("select * from payment where PaymentID = ?",paymentID);
        if (rows.size() == 0){
            return null;
        }else {
            Map paymentMap=(Map)rows.get(0);
            Payment tempPayment=null;
            tempPayment=new Payment();
            String tID=paymentMap.get("PaymentID")+"";
            String tCard=paymentMap.get("CardNumber")+"";
            String tType=paymentMap.get("PaymentType")+"";

            tempPayment.setPaymentID(tID);
            tempPayment.setCardNumber(tCard);
            tempPayment.setPaymentType(tType);
            return tempPayment;
        }



    }
}
