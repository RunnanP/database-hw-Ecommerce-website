package com.cse305.Service;

import com.cse305.Entity.Orders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author Zhenquan Ma
 */

@Service
public class OrdersService {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private char[] orderChar= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N',
            'O','P','Q','R','S','T','U','V','W','X','Y','Z'};

    public boolean checkOrderExistById(String id){
        if (this.getOrderByID(id) == null){
            return false;
        }else
            return true;

    }
    public    String generate_orderID(){
        String orderID ="";
     //   do {
            for (int i = 0; i < 9; i++) {
                orderID += orderChar[(int) (Math.random() * 36)];
            }
       // }while(checkOrderExistById(orderID));
        return orderID;
    }
    public int insertOrder(Orders order){
        return jdbcTemplate.update("insert into orders(OrderID, CustomerID, PaymentID, TrackingNumber, Tax, TotalPrice) values(?,?,?,?,?,?)",
                order.getOrderID(), order.getCustomerID(), order.getPaymentID(), order.getTrackingNumber(), order.getTax(), order.getTotalPrice());
    }

    public void updateOrder(Orders order){
        jdbcTemplate.update("update orders set CustomerID = ?, PaymentID = ?, TrackingNumber = ?, Tax = ?, TotalPrice = ? where OrderID = ?",
                order.getCustomerID(), order.getPaymentID(), order.getTrackingNumber(), order.getTax(), order.getTotalPrice(), order.getOrderID());
    }

    public int deleteOrderById(String id){
        return jdbcTemplate.update("delete from orders where OrderID = ?", id);
    }

    public void deleteAllOrders(){
        jdbcTemplate.update("delete * from orders");
    }

    public List<Orders> getAllOrders(){
        List rows = jdbcTemplate.queryForList("select * from orders");
        Iterator itor = rows.iterator();
        List<Orders> ordersList = new ArrayList<>();
        Orders tempOrder = null;
        while(itor.hasNext()){
            Map orderMap = (Map) itor.next();
            tempOrder = new Orders();
            String tempOrderID = orderMap.get("OrderID") + "";
            String tempCustomerID = orderMap.get("CustomerID") + "";
            String tempPaymentID =orderMap.get("PaymentID") + "";
            String tempTrackingNum = orderMap.get("TrackingNumber") + "";
            double tempTax = Double.parseDouble(orderMap.get("Tax") + "");
            double tempTotalPrice = Double.parseDouble(orderMap.get("TotalPrice") + "");
            tempOrder.setCustomerID(tempCustomerID);
            tempOrder.setOrderID(tempOrderID);
            tempOrder.setPaymentID(tempPaymentID);
            tempOrder.setTrackingNumber(tempTrackingNum);
            tempOrder.setTax(tempTax);
            tempOrder.setTotalPrice(tempTotalPrice);
            ordersList.add(tempOrder);
        }
        return ordersList;
    }

    public int getOrderQuantity() { return this.getAllOrders().size(); }

    public Orders getOrderByID(String id) {
        List rows = jdbcTemplate.queryForList("select * from orders where OrderID = ?", id);
        if(rows.size() == 0){
            return null;
        }
        else {
            Map ordersMap = (Map) rows.get(0);
            Orders tempOrder = new Orders();
            String tempOrderID = ordersMap.get("OrderID") + "";
            String tempCustomerID = ordersMap.get("CustomerID") + "";
            String tempPaymentID = ordersMap.get("PaymentID") + "";
            String tempTrackingNum = ordersMap.get("TrackingNumber") + "";
            String tempTax = ordersMap.get("Tax") + "";
            String tempTotalPrice = ordersMap.get("TotalPrice") + "";
            tempOrder.setCustomerID(tempCustomerID);
            tempOrder.setOrderID(tempOrderID);
            tempOrder.setPaymentID(tempPaymentID);
            tempOrder.setTrackingNumber(tempTrackingNum);
            tempOrder.setTax(Integer.parseInt(tempTax));
            tempOrder.setTotalPrice(Double.parseDouble(tempTotalPrice));
            return tempOrder;
        }
    }

    public List<Orders> getAllOrderFromAId(String id) {
        List rows = jdbcTemplate.queryForList("select * from orders where CustomerID = ?", id);
        Iterator itor = rows.iterator();
        List<Orders> ordersList = new ArrayList<>();
        Orders tempOrder = null;
        while(itor.hasNext()){
            Map orderMap = (Map) itor.next();
            tempOrder = new Orders();
            String tempOrderID = orderMap.get("OrderID") + "";
            String tempCustomerID = orderMap.get("CustomerID") + "";
            String tempPaymentID =orderMap.get("PaymentID") + "";
            String tempTrackingNum = orderMap.get("TrackingNumber") + "";
            double tempTax = Double.parseDouble(orderMap.get("Tax") + "");
            double tempTotalPrice = Double.parseDouble(orderMap.get("TotalPrice") + "");
            tempOrder.setCustomerID(tempCustomerID);
            tempOrder.setOrderID(tempOrderID);
            tempOrder.setPaymentID(tempPaymentID);
            tempOrder.setTrackingNumber(tempTrackingNum);
            tempOrder.setTax(tempTax);
            tempOrder.setTotalPrice(tempTotalPrice);
            ordersList.add(tempOrder);
        }
        return ordersList;
    }

}
