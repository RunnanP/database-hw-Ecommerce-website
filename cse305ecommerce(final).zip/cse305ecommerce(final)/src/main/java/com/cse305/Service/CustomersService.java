package com.cse305.Service;

import com.cse305.Entity.Customers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class CustomersService {
    @Autowired
    private JdbcTemplate jdbcTemplate;




    public int insertCustomers(Customers customers) {
        return jdbcTemplate.update("insert into customers(CustomerID,CPassword,LastName,FirstName,PhoneNumber,Address,Email) values(?,?,?,?,?,?,?)",customers.getCustomerId(),customers.getCpassword(),customers.getlName(),customers.getfName(),customers.getPhoneNumber(),customers.getAddress(),customers.getEmail());

        //jdbcTemplate.update("insert into employee(EmployeeId,EPassword,LastName,FirstName,PhoneNumber,Address,Email) values(?,?,?,?,?,?,?)",customers.getCustomerId(),customers.getCpassword(),customers.getlName(),customers.getfName(),customers.getPhoneNumber(),customers.getAddress(),customers.getEmail());
        //jdbcTemplate.update("insert into users (UserID,Role) VALUES (qwe,wer)");
    }


    public int deleteCustomersById(String id) {
        //jdbcTemplate.update("delete from users where UserID=123");
        //  jdbcTemplate.update("delete from users where UserID=\"" +id+"\"" );

        return jdbcTemplate.update("delete from customers where CustomerID =? " ,id );
    }


    public int updateCustomers(Customers customers){
        return deleteCustomersById(customers.getCustomerId())+insertCustomers(customers);
    }


    public void deleteAllCustomers(){

         jdbcTemplate.update("delete from customers");
    }



    public List<Customers> getAllCustomers(){

        List rows=jdbcTemplate.queryForList("select * from customers");
        Iterator it=rows.iterator();
        List<Customers> customersList=new ArrayList<>();
        Customers tempcustomer=null;
        while(it.hasNext()){
            Map userMap=(Map)it.next();
            tempcustomer=new Customers();
            String tempcustomerid=userMap.get("CustomerID")+"";
            String tempcpassword=userMap.get("CPassword")+"";
            String templname=userMap.get("LastName")+"";
            String tempfname=userMap.get("FirstName")+"";
            String tempphone=userMap.get("PhoneNumber")+"";
            String tempadd=userMap.get("Address")+"";
            String tempemail=userMap.get("Email")+"";
                    tempcustomer.setCustomerId(tempcustomerid);
                    tempcustomer.setCpassword(tempcpassword);
                    tempcustomer.setlName(templname);
                    tempcustomer.setfName(tempfname);
                    tempcustomer.setPhoneNumber(tempphone);
                    tempcustomer.setAddress(tempadd);
                    tempcustomer.setEmail(tempemail);
            customersList.add(tempcustomer);

        }
        return customersList;
    }

    public int getCustomersQuantity(){
        return getAllCustomers().size();
    }

    public Customers getCustomersById(String id) {
        List rows=jdbcTemplate.queryForList("select * from customers where CustomerID = ?",id);
        if(rows.size()==0){
            return null;
        }else{
            Map userMap=(Map)rows.get(0);
            Customers tempcustomer=null;
            tempcustomer=new Customers();
            String tempcustomerid=userMap.get("CustomerID")+"";
            String tempcpassword=userMap.get("CPassword")+"";
            String templname=userMap.get("LastName")+"";
            String tempfname=userMap.get("FirstName")+"";
            String tempphone=userMap.get("PhoneNumber")+"";
            String tempadd=userMap.get("Address")+"";
            String tempemail=userMap.get("Email")+"";
            tempcustomer.setCustomerId(tempcustomerid);
            tempcustomer.setCpassword(tempcpassword);
            tempcustomer.setlName(templname);
            tempcustomer.setfName(tempfname);
            tempcustomer.setPhoneNumber(tempphone);
            tempcustomer.setAddress(tempadd);
            tempcustomer.setEmail(tempemail);
            return tempcustomer;
        }


    }
}
