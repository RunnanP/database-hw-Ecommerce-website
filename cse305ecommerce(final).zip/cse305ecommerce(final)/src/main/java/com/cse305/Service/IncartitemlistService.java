package com.cse305.Service;

import com.cse305.Entity.Customers;
import com.cse305.Entity.Incartitemlist;
import com.cse305.Entity.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class IncartitemlistService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void insertItem2Cart(Item item, Customers customer ){
        jdbcTemplate.update("insert into incartitemlist(CustomerID,ItemID,ItemName,Quantity,UnitPrice,Subtotal) values(?,?,?,?,?,?)"
                ,customer.getCustomerId(),item.getItemID(),item.getItemName(),
                item.getQuantity(),item.getPrice(),item.getPrice()*item.getQuantity());
    }
    public int insertItem2Cart(Item item, String customerID ){
        return jdbcTemplate.update("insert into incartitemlist(CustomerID,ItemID,ItemName,Quantity,UnitPrice,Subtotal) values(?,?,?,?,?,?)"
                ,customerID,item.getItemID(),item.getItemName(),
                item.getQuantity(),item.getPrice(),item.getPrice()*item.getQuantity());
    }

    public void deleteItemByIdAndCustomerID(String id,String customerID) {
        jdbcTemplate.update("delete from incartitemlist where ItemID=? and CustomerID = ?" ,id,customerID );
    }

    public void updateItem(Item i,String customerID){
        deleteItemByIdAndCustomerID(i.getItemID(),customerID);
        insertItem2Cart(i,customerID);
    }

    public void deleteAllItemFromACustomerCart(String customerID){

        jdbcTemplate.update("delete from incartitemlist where CustomerID = ?",customerID);
    }
    public void deleteAllCart(){

        jdbcTemplate.update("delete * from incartitemlist");
    }
    public List<Incartitemlist> getAllItemFromACustomerCart(String customerID){

    List rows=jdbcTemplate.queryForList("select * from incartitemlist where CustomerID = ?",customerID);
    Iterator it=rows.iterator();
    List<Incartitemlist> ItemList=new ArrayList<>();
    Incartitemlist tempItem=null;
     while(it.hasNext()){
        Map itemMap=(Map)it.next();
        tempItem=new Incartitemlist();
        String owner = itemMap.get("CustomerID")+"";
        String tItemid=itemMap.get("ItemID")+"";
        String tItemName=itemMap.get("ItemName")+"";
        int tItemQuantity=Integer.parseInt(itemMap.get("Quantity")+"");
         double tItemUnitPrice = Double.parseDouble(itemMap.get("UnitPrice")+"");
        double tItemPrice=Double.parseDouble(itemMap.get("Subtotal")+"");
        tempItem.setCustomerID(owner);
        tempItem.setItemID(tItemid);
        tempItem.setItemName(tItemName);
        tempItem.setQuantity(tItemQuantity);
         tempItem.setUnitPrice(tItemUnitPrice);

         tempItem.setSubtotal(tItemPrice);

        ItemList.add(tempItem);

    }

        return ItemList;
}

    public Incartitemlist getSpecificItemFromACustomerCart(String customerID,String itemid){

        List rows=jdbcTemplate.queryForList("select * from incartitemlist where CustomerID = ? and ItemID= ?",customerID,itemid);
        if(rows.size()==0){
            return null;
        }else {
            Map itemMap=(Map)rows.get(0);
            Incartitemlist tempItem =new Incartitemlist();
            String owner = itemMap.get("CustomerID")+"";
            String tItemid=(itemMap.get("ItemID")+"");
            String tItemName=itemMap.get("ItemName")+"";
            int tItemQuantity=Integer.parseInt(itemMap.get("Quantity")+"");
            double tItemUnitPrice = Double.parseDouble(itemMap.get("UnitPrice")+"");
            double tItemPrice=Double.parseDouble(itemMap.get("Subtotal")+"");
            tempItem.setCustomerID(owner);
            tempItem.setItemID(tItemid);
            tempItem.setItemName(tItemName);
            tempItem.setQuantity(tItemQuantity);
            tempItem.setUnitPrice(tItemUnitPrice);
            tempItem.setSubtotal(tItemPrice);
            return tempItem;

        }

    }

    public int getItemQuantityACustomerCart(String customerID){
        return getAllItemFromACustomerCart(customerID).size();
    }

}
