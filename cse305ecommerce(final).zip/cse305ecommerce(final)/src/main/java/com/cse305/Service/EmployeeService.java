package com.cse305.Service;

import com.cse305.Entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class EmployeeService {

    @Autowired
    private JdbcTemplate jdbcTemplate;




    public int insertEmployee(Employee employee) {
        return jdbcTemplate.update("insert into employee(EmployeeID,EPassword,LastName,FirstName," +
                "PhoneNumber,Address,Email) values(?,?,?,?,?,?,?)",employee.getEmployeeId(),employee.getEPassword(),
                employee.getlName(),employee.getfName(),employee.getPhoneNumber(),employee.getAddress(),employee.getEmail());

        //jdbcTemplate.update("insert into employee(EmployeeId,EPassword,LastName,FirstName,PhoneNumber,Address,Email) values(?,?,?,?,?,?,?)",employee.getEmployeeId(),employee.getCpassword(),employee.getlName(),employee.getfName(),employee.getPhoneNumber(),employee.getAddress(),employee.getEmail());
        //jdbcTemplate.update("insert into users (UserID,Role) VALUES (qwe,wer)");
    }


    public int deleteEmployeeById(String id) {
        //jdbcTemplate.update("delete from users where UserID=123");
        //  jdbcTemplate.update("delete from users where UserID=\"" +id+"\"" );

        return jdbcTemplate.update("delete from employee where EmployeeId=?" ,id );
    }


    public int updateEmployee(Employee employee){
        return deleteEmployeeById(employee.getEmployeeId()) + insertEmployee(employee);
    }


    public void deleteAllEmployee(){

        jdbcTemplate.update("delete * from employee");
    }



    public List<Employee> getAllEmployee(){

        List rows=jdbcTemplate.queryForList("select * from employee");
        Iterator it=rows.iterator();
        List<Employee> employeeList=new ArrayList<>();
        Employee tempemployee=null;
        while(it.hasNext()){
            Map userMap=(Map)it.next();
            tempemployee=new Employee();
            String tempemployeeid=userMap.get("EmployeeID")+"";
            String tempcpassword=userMap.get("EPassword")+"";
            String templname=userMap.get("LastName")+"";
            String tempfname=userMap.get("FirstName")+"";
            String tempphone=userMap.get("PhoneNumber")+"";
            String tempadd=userMap.get("Address")+"";
            String tempemail=userMap.get("Email")+"";
            tempemployee.setEmployeeId(tempemployeeid);
            tempemployee.setEPassword(tempcpassword);
            tempemployee.setlName(templname);
            tempemployee.setfName(tempfname);
            tempemployee.setPhoneNumber(tempphone);
            tempemployee.setAddress(tempadd);
            tempemployee.setEmail(tempemail);
            employeeList.add(tempemployee);

        }
        return employeeList;
    }

    public int getEmployeeQuantity(){
        return getAllEmployee().size();
    }

    public Employee getEmployeeById(String id) {
        List rows=jdbcTemplate.queryForList("select * from employee where EmployeeID = ?",id);
        if(rows.size()==0){
            return null;
        }else{
            Map userMap=(Map)rows.get(0);
            Employee tempemployee=null;
            tempemployee=new Employee();
            String tempemployeeid=userMap.get("EmployeeID")+"";
            String tempcpassword=userMap.get("EPassword")+"";
            String templname=userMap.get("LastName")+"";
            String tempfname=userMap.get("FirstName")+"";
            String tempphone=userMap.get("PhoneNumber")+"";
            String tempadd=userMap.get("Address")+"";
            String tempemail=userMap.get("Email")+"";
            tempemployee.setEmployeeId(tempemployeeid);
            tempemployee.setEPassword(tempcpassword);
            tempemployee.setlName(templname);
            tempemployee.setfName(tempfname);
            tempemployee.setPhoneNumber(tempphone);
            tempemployee.setAddress(tempadd);
            tempemployee.setEmail(tempemail);
            return tempemployee;
        }


    }
}
