package com.cse305.Service;

import com.cse305.Entity.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class ItemService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int insertItem(Item item){
        return jdbcTemplate.update("insert into item(ItemID,ItemName,Quantity,Price) values(?,?,?,?)"
                ,item.getItemID(),item.getItemName(),item.getQuantity(),item.getPrice());
    }

    public int deleteItemById(String id) {
        return jdbcTemplate.update("delete from item where ItemID=?" ,id );
    }

    public void updateItem(Item i){
        deleteItemById(i.getItemID());
        insertItem(i);
    }

    public void deleteAllItem(){

        jdbcTemplate.update("delete * from item");
    }

    public List<Item> getAllItem(){

        List rows=jdbcTemplate.queryForList("select * from item");
        Iterator it=rows.iterator();
        List<Item> ItemList=new ArrayList<>();
        Item tempItem=null;
        while(it.hasNext()){
            Map itemMap=(Map)it.next();
            tempItem=new Item();
            String tItemid=itemMap.get("ItemID")+"";
            String tItemName=itemMap.get("ItemName")+"";
            int tItemQuantity=Integer.parseInt(itemMap.get("Quantity")+"");
            double tItemPrice=Double.parseDouble(itemMap.get("Price")+"");
            tempItem.setItemID(tItemid);
            tempItem.setItemName(tItemName);
            tempItem.setQuantity(tItemQuantity);
            tempItem.setPrice(tItemPrice);

            ItemList.add(tempItem);

        }
        return ItemList;
    }
    public int getItemQuantity(){
        return getAllItem().size();
    }

    public Item getItemById(String id) {
        List rows=jdbcTemplate.queryForList("select * from item where ItemID = ?",id);
        if (rows.size() == 0){
            return null;
        }else {
            Map itemMap=(Map)rows.get(0);
            Item tempItem=null;
            tempItem=new Item();
            String tItemid=itemMap.get("ItemID")+"";
            String tItemName=itemMap.get("ItemName")+"";
            int tItemQuantity=Integer.parseInt(itemMap.get("Quantity")+"");
            double tItemPrice=Double.parseDouble(itemMap.get("Price")+"");
            tempItem.setItemID(tItemid);
            tempItem.setItemName(tItemName);
            tempItem.setQuantity(tItemQuantity);
            tempItem.setPrice(tItemPrice);
            return tempItem;
        }
           

        
    }
}
