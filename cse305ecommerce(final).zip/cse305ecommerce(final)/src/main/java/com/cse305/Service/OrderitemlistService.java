package com.cse305.Service;

import com.cse305.Entity.Orderitemlist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class OrderitemlistService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int insertOrderitemlist(Orderitemlist orderitemlist){
        return jdbcTemplate.update("insert into orderitemlist(OrderID,ItemID,ItemName,ItemNumber,UnitPrice,Subtotal) values(?,?,?,?,?,?)"
                ,orderitemlist.getOrderID(),orderitemlist.getItemID(),orderitemlist.getItemName(),
                orderitemlist.getItemNumber(),orderitemlist.getUnitPrice(),orderitemlist.getSubtotal());
    }

    public void deleteOrderitemlistById(String id) {
        jdbcTemplate.update("delete from orderitemlist where OrderID=?" ,id );
    }

    public void updateOrderitemlist(Orderitemlist i){
        deleteOrderitemlistById(i.getOrderID());
        insertOrderitemlist(i);
    }

    public void deleteAllOrderitemlist(){

        jdbcTemplate.update("delete * from orderitemlist");
    }

    public List<Orderitemlist> getOrderitemlistByOrderId(String id){

        List rows=jdbcTemplate.queryForList("select * from orderitemlist where OrderID = ?",id);
        Iterator it=rows.iterator();
        List<Orderitemlist> OrderitemlistList=new ArrayList<>();
        Orderitemlist tempOrderitemlist=null;
        while(it.hasNext()){
            Map itemMap=(Map)it.next();
            tempOrderitemlist=new Orderitemlist();
            String tOrderId=itemMap.get("OrderID")+"";
            String tItemId=itemMap.get("ItemID")+"";
            String tName=itemMap.get("ItemName")+"";
            int tNumber=Integer.parseInt(itemMap.get("ItemNumber")+"");
            double tUnit=Double.parseDouble(itemMap.get("UnitPrice")+"");
            tempOrderitemlist.setOrderID(tOrderId);
            tempOrderitemlist.setItemID(tItemId);
            tempOrderitemlist.setItemName(tName);
            tempOrderitemlist.setItemNumber(tNumber);
            tempOrderitemlist.setUnitPrice(tUnit);

            OrderitemlistList.add(tempOrderitemlist);

        }
        return OrderitemlistList;
    }
    public Orderitemlist getOrderitemlistByOrderIdAndItemId(String orderId,String itemId){

        List rows=jdbcTemplate.queryForList("select * from orderitemlist where OrderID = ? ItemID = ?",orderId,itemId);
        if(rows.size()==0){
            return null;
        }else{
            Map userMap=(Map)rows.get(0);
            Orderitemlist temp=new Orderitemlist();
            temp.setOrderID(userMap.get("OrderID")+"");
            temp.setItemID(userMap.get("ItemID")+"");
            temp.setItemName(userMap.get("ItemName")+"");
            temp.setItemNumber(Integer.parseInt(userMap.get("ItemNumber")+""));
            temp.setUnitPrice(Double.parseDouble(userMap.get("UnitPrice")+""));

            return temp;
        }
    }
    public int getOrderitemlistQuantityByOrderId(String id){
        return getOrderitemlistByOrderId(id).size();
    }


}
