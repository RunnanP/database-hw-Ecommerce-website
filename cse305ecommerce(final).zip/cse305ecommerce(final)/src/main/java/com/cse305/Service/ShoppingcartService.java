package com.cse305.Service;

import com.cse305.Entity.Shoppingcart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Service
public class ShoppingcartService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int insertShoppingcart(Shoppingcart shoppingcart){
        return jdbcTemplate.update("insert into shoppingcart(CustomerID,Total) values(?,?)"
                ,shoppingcart.getCustomerID(),shoppingcart.getTotal());
    }

    public int deleteShoppingcartById(String id) {
        return jdbcTemplate.update("delete from shoppingcart where CustomerID=?" ,id );
    }

    public void updateShoppingcart(Shoppingcart shoppingcart){
        deleteShoppingcartById(shoppingcart.getCustomerID());
        insertShoppingcart(shoppingcart);
    }

    public void deleteAllShoppingcart(){

        jdbcTemplate.update("delete * from shoppingcart");
    }

    public List<Shoppingcart> getAllShoppingcart(){

        List rows=jdbcTemplate.queryForList("select * from shoppingcart");
        Iterator it=rows.iterator();
        List<Shoppingcart> ShoppingcartList=new ArrayList<>();
        Shoppingcart tempShoppingcart=null;
        while(it.hasNext()){
            Map shoppingcartMap=(Map)it.next();
            tempShoppingcart=new Shoppingcart();

            String tID=shoppingcartMap.get("CustomerID")+"";
            double tTotal=Double.parseDouble(shoppingcartMap.get("Total")+"");

            tempShoppingcart.setCustomerID(tID);
            tempShoppingcart.setTotal(tTotal);

            ShoppingcartList.add(tempShoppingcart);

        }
        return ShoppingcartList;
    }
    public int getShoppingcartQuantity(){
        return getAllShoppingcart().size();
    }

    public Shoppingcart getShoppingcartById(String customerID) {
        List rows=jdbcTemplate.queryForList("select * from shoppingcart where CustomerID = ?",customerID);
        if (rows.size()==0){
            return null;
        }else {
            Map shoppingcartMap=(Map)rows.get(0);
            Shoppingcart tempShoppingcart=null;
            tempShoppingcart=new Shoppingcart();
            String tID=shoppingcartMap.get("CustomerID")+"";
            double tTotal=Double.parseDouble(shoppingcartMap.get("Total")+"");

            tempShoppingcart.setCustomerID(tID);
            tempShoppingcart.setTotal(tTotal);
            return tempShoppingcart;
        }



    }



    public double getShoppingTotalPriceByCustomerID(String customerID){

        return getShoppingcartById(customerID).getTotal();
    }
}
