package com.cse305.Controller;

import com.cse305.Entity.Payment;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    private PaymentService paymentService;

    public boolean checkPaymentExistById(@RequestParam("id") String id){
        if (this.paymentService.getPaymentByPaymentId(id) == null){
            return false;
        }else
            return true;

    }

    public ResponseEntity insertPayment(Payment payment) {
        AjaxResponse result = new AjaxResponse();
        if (checkPaymentExistById(payment.getPaymentID())) {
            result.setMsg("Payment already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.paymentService.insertPayment(payment) > 0) {
                result.setMsg("add success");
                ArrayList a = new ArrayList();
                a.add(payment);
                result.setList(a);
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }
    }

    @RequestMapping(value = "/insertPayment", method = RequestMethod.POST)
    public ResponseEntity insertPayment(@RequestParam(value = "cardNumber") String cardNumber,
                                 @RequestParam(value = "paymentType") String paymentType ){
        // return "redirect:/index.html";
        return insertPayment(new Payment(paymentService.generate_paymentID(), cardNumber, paymentType));
    }

    @RequestMapping(value="/deletePaymentById", method=RequestMethod.DELETE)
    public ResponseEntity deletePaymentById(@RequestParam(value = "paymentID") String paymentID){
        AjaxResponse result = new AjaxResponse();
        if (checkPaymentExistById(paymentID)) {
            if (this.paymentService.deletePaymentById(paymentID)> 0) {
                result.setMsg("delete success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("delete fail");
                return ResponseEntity.ok(result);
            }
        }else {
            result.setMsg("payment does not exsits");
            return ResponseEntity.ok(result);
        }
    }

    @RequestMapping(value="/deleteAllPayment", method=RequestMethod.DELETE)
    public ResponseEntity deleteAllPayment(){
        AjaxResponse result = new AjaxResponse();
        this.paymentService.deleteAllPayment();
        result.setMsg("delete all payment");
        return ResponseEntity.ok(result);

    }

    @RequestMapping(value="/updatePayment", method=RequestMethod.POST)
    public ResponseEntity updatePayment(Payment payment){
        AjaxResponse result = new AjaxResponse();
        if (this.paymentService.updatePayment(payment) == 2) {
            result.setMsg("update success");
            return ResponseEntity.ok(result);
        }else {
            result.setMsg("update fail");
            return ResponseEntity.ok(result);
        }
    }

    @RequestMapping(value="/getPaymentByPaymentId", method=RequestMethod.GET)
    public ResponseEntity getPaymentByPaymentId(@PathVariable("paymentID") String paymentID){
        AjaxResponse result = new AjaxResponse();
        Payment temp = this.paymentService.getPaymentByPaymentId(paymentID);
        if(temp == null){
            result.setMsg("payment does not exist");
            return ResponseEntity.ok(result);

        }else {
            result.setMsg("payment found");
            List l = new ArrayList();
            l.add(temp);
            result.setList(l);
            return ResponseEntity.ok(result);

        }
    }

    @RequestMapping(value="/getAllPayment", method=RequestMethod.GET)
    public ResponseEntity getAllPayment(){
        AjaxResponse result = new AjaxResponse();
        result.setList(this.paymentService.getAllPayment());
        result.setMsg("all shipment");
        return ResponseEntity.ok(result);

    }

    /*@RequestMapping(value="/getPaymentQuantity",method=RequestMethod.GET)
    public int getPaymentQuantity(){
        return this.paymentService.getPaymentQuantity();
    }*/
}
