package com.cse305.Controller;

import com.cse305.Entity.Orders;
import com.cse305.Response.AjaxResponse;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.OrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/orders")
public class OrdersController {
    @Autowired
    private OrdersService ordersService;


    private char[] orderChar= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N',
            'O','P','Q','R','S','T','U','V','W','X','Y','Z'};

    public boolean checkOrderExistById(String id){
        if (this.ordersService.getOrderByID(id) == null){
            return false;
        }else
            return true;

    }



    public ResponseEntity<?> insertOrder(@RequestBody Orders order){
        AjaxResponse result = new AjaxResponse();
        if (checkOrderExistById(order.getOrderID())) {
            result.setMsg("order already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.ordersService.insertOrder(order) > 0) {
                result.setMsg("add success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }
    }
    @RequestMapping(value="/insertOrder", method = RequestMethod.POST)
    public ResponseEntity<?> insertOrder(@RequestParam(value="orderId") String OrderID,
                                             @RequestParam(value="customerId") String CustomerID,
                                             @RequestParam(value="paymentId") String PaymentID,
                                             @RequestParam(value="trackingNumber") String TrackingNumber,
                                             @RequestParam(value="tax") double Tax,
                                             @RequestParam(value="totalPrice") double TotalPrice) {

        return insertOrder(new Orders(OrderID,CustomerID,PaymentID,TrackingNumber,Tax,TotalPrice));


    }

    @RequestMapping(value = "/deleteOrderById", method = RequestMethod.DELETE)
    public ResponseEntity deleteOrderById(@RequestParam(value = "id") String id) {
        AjaxResponse result = new AjaxResponse();
        if (checkOrderExistById(id)) {
            if (this.ordersService.deleteOrderById(id) > 0) {
                result.setMsg("delete success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("delete fail");
                return ResponseEntity.ok(result);
            }
        }else {
            result.setMsg("order does not exsits");
            return ResponseEntity.ok(result);
        }
    }

    @RequestMapping(value = "/deleteAllOrders", method = RequestMethod.DELETE)
    public void deleteAllOrders(){
        this.ordersService.deleteAllOrders();
    }

    @RequestMapping(value = "/getAllOrders", method = RequestMethod.GET)
    public ResponseEntity getAllOrder(){
        AjaxResponse result = new AjaxResponse();
        result.setList(this.ordersService.getAllOrders());
        result.setMsg("all orders");
        return ResponseEntity.ok(result);
    }

    /* @RequestMapping(value = "/getOrdersQuantity", method = RequestMethod.GET)
     public int getOrdersQuantity(){
         return this.getOrdersQuantity();
     }*/
    @RequestMapping(value = "/getOrdersHistoryByCustomers",method = RequestMethod.GET)
    public ResponseEntity getOrdersHistoryByCustomers(@RequestParam(value = "customerID") String cusotmerID){
        AjaxResponse result = new AjaxResponse();
        result.setList(ordersService.getAllOrderFromAId(cusotmerID));
        result.setMsg("items");
        return ResponseEntity.ok(result);


    }
}
