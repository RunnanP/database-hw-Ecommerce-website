package com.cse305.Controller;

import com.cse305.Entity.Shipment;
import com.cse305.Entity.Shoppingcart;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.ShipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sun.security.provider.SHA;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/shipment")
public class ShipmentController {
    @Autowired
    private ShipmentService shipmentService;

/*    private char[] trackingChar= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N',
            'O','P','Q','R','S','T','U','V','W','X','Y','Z'};*/
    public boolean checkOrderExistByTrackingNumber(@RequestParam("id") String id){
        if (this.shipmentService.getShipmentByTrackingNumber(id) == null){
            return false;
        }else
            return true;

    }
    public ResponseEntity insertShipment(Shipment shipment) {
        AjaxResponse result = new AjaxResponse();
        if (checkOrderExistByTrackingNumber(shipment.getTrackingNumber())) {
            result.setMsg("shipment already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.shipmentService.insertShipment(shipment) > 0) {
                ArrayList a = new ArrayList();
                a.add(shipment);
                result.setList(a);
                result.setMsg("add shipment success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add shipment fail");
                return ResponseEntity.ok(result);
            }
        }
    }

    @RequestMapping(value = "/insertShipment", method = RequestMethod.POST)
    public ResponseEntity insertShipment(@RequestParam(value = "address") String address,
                                         @RequestParam(value = "typeOfShipment") String type) {
        return insertShipment(new Shipment(shipmentService.generate_trackingNum(), address, 5.0, type));

    }

    @RequestMapping(value="/deleteShipmentByTrackingNumber", method=RequestMethod.DELETE)
    public ResponseEntity deleteShipmentByTrackingNumber(@RequestParam(value = "trackingNumber") String trackingNumber){
        AjaxResponse result = new AjaxResponse();
        if (checkOrderExistByTrackingNumber(trackingNumber)) {
            if (this.shipmentService.deleteShipmentByTrackingNumber(trackingNumber)> 0) {
                result.setMsg("delete success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("delete fail");
                return ResponseEntity.ok(result);
            }
        }else {
            result.setMsg("shipment does not exsits");
            return ResponseEntity.ok(result);
        }
    }

    @RequestMapping(value="/deleteAllShipment", method=RequestMethod.DELETE)
    public ResponseEntity deleteAllShipment(){
        AjaxResponse result = new AjaxResponse();
        this.shipmentService.deleteAllShipment();
        result.setMsg("delete all shipment");
        return ResponseEntity.ok(result);

    }

    @RequestMapping(value="/updateShipment", method=RequestMethod.POST)
    public ResponseEntity updateShipment(Shipment shipment){
        AjaxResponse result = new AjaxResponse();
        if (this.shipmentService.updateShipment(shipment) == 2) {
            result.setMsg("update success");
            return ResponseEntity.ok(result);
        }else {
            result.setMsg("update fail");
            return ResponseEntity.ok(result);
        }
    }

    @RequestMapping(value="/getShipmentByTrackingNumber", method=RequestMethod.GET)
    public ResponseEntity getShipmentByTrackingNumber(@PathVariable("trackingNumber") String trackingNumber){
        AjaxResponse result = new AjaxResponse();
        Shipment temp = this.shipmentService.getShipmentByTrackingNumber(trackingNumber);
        if(temp == null){
            result.setMsg("shipment does not exist");
            return ResponseEntity.ok(result);

        }else {
            result.setMsg("shipment found");
            List l = new ArrayList();
            l.add(temp);
            result.setList(l);
            return ResponseEntity.ok(result);

        }
    }

    @RequestMapping(value="/getAllShipment", method=RequestMethod.GET)
    public ResponseEntity getAllShipment(){
        AjaxResponse result = new AjaxResponse();
        result.setList(this.shipmentService.getAllShipment());
        result.setMsg("all shipment");
        return ResponseEntity.ok(result);
    }

    /*@RequestMapping(value="/getShipmentQuantity",method=RequestMethod.GET)
    public int getShipmentQuantity(){
        return this.shipmentService.getShipmentQuantity();
    }*/

}
