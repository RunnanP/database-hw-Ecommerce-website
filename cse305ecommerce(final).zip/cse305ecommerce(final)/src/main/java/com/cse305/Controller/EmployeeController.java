package com.cse305.Controller;


import com.cse305.Entity.Employee;
import com.cse305.Entity.Users;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.EmployeeService;
import com.cse305.Service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/employee")
public class EmployeeController {



    @Autowired
    private EmployeeService employeeService;
    @Autowired
    public EmployeeService getEmployeeService() {
        return employeeService;
    }
    //helper method
    public boolean checkEmployeeExistById(@RequestParam("id") String id){
        if (this.employeeService.getEmployeeById(id) == null){
            return false;
        }else
            return true;

    }
    @RequestMapping(value = "/rigsterEnployee", method = RequestMethod.POST)
    public String rigsterEnployee(@RequestParam(value = "id") String CustomerId,
                                  @RequestParam(value = "password") String CPassword,
                                  @RequestParam(value = "lname") String LastName,
                                  @RequestParam(value = "fname") String FirstName,
                                  @RequestParam(value = "phone") String PhoneNumber,
                                  @RequestParam(value = "address") String Address, @RequestParam(value = "email") String Email) {
        int s = employeeService.insertEmployee(new Employee(CustomerId, CPassword, LastName,
                FirstName, PhoneNumber, Address, Email));
        if (s > 0) {
            return "/employeeHomePage.html";
        } else {
            return "/loginFail.html";
        }
    }
    public ResponseEntity insertEmployee( Employee employee) {
        AjaxResponse result = new AjaxResponse();
        if (checkEmployeeExistById(employee.getEmployeeId())) {
            result.setMsg("username already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.employeeService.insertEmployee(employee) > 0) {
                result.setMsg("add success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }
    }
    @RequestMapping(value="/insertEmployee", method = RequestMethod.POST)
    public ResponseEntity insertEmployee(@RequestParam(value="id") String CustomerId, @RequestParam(value="password") String CPassword,
                                 @RequestParam(value="lname") String LastName, @RequestParam(value="fname") String FirstName,
                                 @RequestParam(value="phone") String PhoneNumber, @RequestParam(value="address") String Address,
                                 @RequestParam(value="email") String Email) {
        return insertEmployee(new Employee(CustomerId,CPassword,LastName,FirstName,PhoneNumber,Address,Email));

    }



    @RequestMapping(value="/deleteEmployeeById", method=RequestMethod.DELETE)
    public ResponseEntity deleteEmployeeById(@RequestParam(value = "id", defaultValue = "") String id){
        AjaxResponse result = new AjaxResponse();
        if (checkEmployeeExistById(id)) {
            if (this.employeeService.deleteEmployeeById(id) > 0) {
                result.setMsg("delete success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("delete fail");
                return ResponseEntity.ok(result);
            }
        }else {
            result.setMsg("employee does not exsits");
            return ResponseEntity.ok(result);
        }
    }



    @RequestMapping(value="/deleteAllEmployee", method=RequestMethod.DELETE)
    public ResponseEntity deleteAllEmployee(){
        AjaxResponse result = new AjaxResponse();
        this.employeeService.deleteAllEmployee();
        result.setMsg("delete all");
        return ResponseEntity.ok(result);

    }


    @RequestMapping(value="/updateEmployee", method=RequestMethod.POST)
    public ResponseEntity updateEmployee(@RequestParam(value="id") String EmployeeID,
                                         @RequestParam(value="password") String CPassword,
                                         @RequestParam(value="lname") String LastName,
                                         @RequestParam(value="fname") String FirstName,
                                         @RequestParam(value="phone") String PhoneNumber,
                                         @RequestParam(value="address") String Address,
                                         @RequestParam(value="email") String Email){
        AjaxResponse result = new AjaxResponse();
        Employee temp = new Employee(EmployeeID,CPassword,LastName,FirstName,PhoneNumber,Address,Email);
        if (!checkEmployeeExistById(EmployeeID)) {
            result.setMsg("customer does not exist");
            return ResponseEntity.ok(result);
        }else {
            if (this.employeeService.updateEmployee(temp) > 0) {
                result.setMsg("update success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("update fail");
                return ResponseEntity.ok(result);
            }
        }
    }



    @RequestMapping(value="/getEmployeeByID", method=RequestMethod.GET)
    public ResponseEntity getEmployeeById(@RequestParam("id") String id){
        AjaxResponse result = new AjaxResponse();
        Employee temp = this.employeeService.getEmployeeById(id);
        if(temp == null){
            result.setMsg("employee does not exist");
            return ResponseEntity.ok(result);

        }else {
            result.setMsg("employee found");
            List l = new ArrayList();
            l.add(temp);
            result.setList(l);
            return ResponseEntity.ok(result);

        }
    }




    @RequestMapping(value="/getAllEmployee", method=RequestMethod.GET)
    public ResponseEntity getAllEmployee(){
        AjaxResponse result = new AjaxResponse();
        result.setList(this.employeeService.getAllEmployee());
        result.setMsg("all customer");
        return ResponseEntity.ok(result);




    }


    @RequestMapping(value="/getUsersQuantity",method=RequestMethod.GET)
    public int getEmployeeQuantity(){
        return this.employeeService.getEmployeeQuantity();
    }

    @RequestMapping(value="/loginEmployee",method=RequestMethod.POST)
    /*public String loginEmployee(@RequestParam(value="id") String id, @RequestParam(value = "password") String pw) {
        Employee ep = this.employeeService.getEmployeeById(id);
        if (ep == null) {
            return "/loginFail.html";
        } else {
            if (pw.equals(ep.getEPassword())) {
                return "/loginFail.html";

            } else {
                return "/employeeHomePage.html";


            }
        }
    }*/
    public ResponseEntity loginCustomer(@RequestParam(value="id") String id,@RequestParam(value = "password") String pw) {
        AjaxResponse result = new AjaxResponse();

        Employee  cs = this.employeeService.getEmployeeById(id);
        if (cs == null){
            result.setMsg("/loginfail.html");
            return ResponseEntity.ok(result);
        }else{
            if (pw.equals(cs.getEPassword())){
                result.setMsg("/employeeHomePage.html");
                return ResponseEntity.ok(result);
            }else {
                result.setMsg("/loginfail.html");
                return ResponseEntity.ok(result);


            }
        }

    }

/*    @RequestMapping(value="/checkEmployee",method=RequestMethod.GET)
    public String checkEmployee(@RequestParam(value="id") String id, @RequestParam(value = "password") String pw) {
//        AjaxResponse result = new AjaxResponse();
        Employee ep = this.employeeService.getEmployeeById(id);
        if (ep == null) {
            return "/loginfail.htlm";
        } else {
            if (pw.equals(ep.getEPassword())) {
                return "/employeeHomePage.html";
            } else {
                return "/loginfail.htlm";
            }
        }
    }*/
}
