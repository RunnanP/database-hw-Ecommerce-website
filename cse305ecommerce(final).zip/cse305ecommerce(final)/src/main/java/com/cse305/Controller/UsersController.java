package com.cse305.Controller;



import com.cse305.Entity.Users;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


    @Controller
    @RequestMapping("/users")
    public class UsersController {

        @Autowired
        private UsersService usersService;

        public UsersService getUsersService() {
            return usersService;
        }

        @RequestMapping(value="/insertUsers", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
        public ResponseEntity insertUsers(@RequestBody Users users) {

            AjaxResponse result = new AjaxResponse();
            if (checkUsersExistById(users.getUserId())) {
                result.setMsg("user already exsits");
                return ResponseEntity.ok(result);
            } else {
                if (this.usersService.insertUsers(users) > 0) {
                    result.setMsg("add success");
                    return ResponseEntity.ok(result);
                } else {
                    result.setMsg("add error");
                    return ResponseEntity.ok(result);
                }
            }


        }

    @RequestMapping(value="/insertUsers", method = RequestMethod.POST)
    public ResponseEntity insertUsers(@RequestParam(value="id") String id, @RequestParam(value="role") String role) {

            return insertUsers(new Users(id,role));


    }


        //employee
        @RequestMapping(value="/deleteUsersById", method=RequestMethod.DELETE)
        public ResponseEntity deleteUsersById(@RequestParam(value = "id", defaultValue = "") String id){
            AjaxResponse result = new AjaxResponse();
            Users temp =  this.usersService.getUsersById(id);
            if (temp != null) {
                if(usersService.deleteUsersById(id)>0){
                    result.setMsg("success to delete");
                    return ResponseEntity.ok(result);
                }else {
                    result.setMsg("fail to delete");
                    return ResponseEntity.ok(result);

                }
            }else{
                result.setMsg("User does not exsit");
                return ResponseEntity.ok(result);
            }

        }



        @RequestMapping(value="/deleteAllUsers", method=RequestMethod.DELETE)
        public void deleteAllUsers(){
            this.usersService.deleteAllUsers();

        }


        @RequestMapping(value="/updateUsers", method=RequestMethod.POST)
        public ResponseEntity updateUsers(Users users){
            AjaxResponse result = new AjaxResponse();
            if (this.usersService.updateUsers(users) > 0){
                result.setMsg("change success");
                return ResponseEntity.ok(result);
            }else{
                result.setMsg("change fail");
                return ResponseEntity.ok(result);
            }
        }



        @RequestMapping(value="/getUsersById", method=RequestMethod.GET)
        public ResponseEntity getUsersById(@RequestParam("id") String id){
            AjaxResponse result = new AjaxResponse();
            Users temp = this.usersService.getUsersById(id);
            if(temp == null){
                result.setMsg("user does not exist");
                return ResponseEntity.ok(result);

            }else {
                result.setMsg("user found");
                List l = new ArrayList();
                l.add(temp);
                result.setList(l);
                return ResponseEntity.ok(result);

            }

        }

        public boolean checkUsersExistById(@RequestParam("id") String id){
            if (this.usersService.getUsersById(id) == null){
                return false;
            }else
                return true;

        }



        @RequestMapping(value="/getAllUser", method=RequestMethod.GET)
        public ResponseEntity getAllUser(){
            AjaxResponse result = new AjaxResponse();
            result.setList(this.usersService.getAllUser());
            result.setMsg("all users");
            return ResponseEntity.ok(result);

        }


       /* @RequestMapping(value="/getUsersQuantity",method=RequestMethod.GET)
        public int getUsersQuantity(){
            return this.usersService.getUsersQuantity();
        }*/




    }

