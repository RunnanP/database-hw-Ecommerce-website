package com.cse305.Controller;

import com.cse305.Entity.Customers;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.CustomersService;
import com.cse305.Service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping("/customers")
public class CustomersController {


    @Autowired
    private CustomersService customersService;
    @Autowired
    private UsersService usersService;

    public CustomersService getCustomersService() {
        return customersService;
    }

    public boolean checkCustomerExistById(String id) {
        if (this.customersService.getCustomersById(id) == null) {
            return false;
        } else
            return true;

    }

    public ResponseEntity<?> insertCustomers(Customers customers) {
        AjaxResponse result = new AjaxResponse();
        if (usersService.getUsersById(customers.getCustomerId()) != null) {
            result.setMsg("username already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.customersService.insertCustomers(customers) > 0) {
                result.setMsg("add success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }

    }

    @RequestMapping(value = "/rigsterCustomer", method = RequestMethod.POST)
    public String rigsterCustomer(@RequestParam(value = "id") String CustomerId,
                                             @RequestParam(value = "password") String CPassword,
                                             @RequestParam(value = "lname") String LastName,
                                             @RequestParam(value = "fname") String FirstName,
                                             @RequestParam(value = "phone") String PhoneNumber,
                                             @RequestParam(value = "address") String Address, @RequestParam(value = "email") String Email) {
        int s =customersService.insertCustomers(new Customers(CustomerId, CPassword, LastName,
                FirstName, PhoneNumber, Address, Email));
        if (s>0){
            return "/customerHomePage.html";
        }else {
            return "/loginFail.html";
        }

    }

    @RequestMapping(value="/insertCustomers", method = RequestMethod.POST)
    public ResponseEntity<?> insertCustomers(@RequestParam(value="id") String CustomerId,
                                  @RequestParam(value="password") String CPassword,
                                  @RequestParam(value="lname") String LastName,
                                  @RequestParam(value="fname") String FirstName,
                                  @RequestParam(value="phone") String PhoneNumber,
                                  @RequestParam(value="address") String Address,@RequestParam(value="email") String Email) {

        return insertCustomers(new Customers(CustomerId,CPassword,LastName,FirstName,PhoneNumber,Address,Email));


    }



    @RequestMapping(value="/deleteCustomersById", method=RequestMethod.GET)
    public ResponseEntity deleteCustomersById(@RequestParam(value = "id") String id){
        AjaxResponse result = new AjaxResponse();
        if (checkCustomerExistById(id)) {
            if (this.customersService.deleteCustomersById(id) > 0) {
                result.setMsg("delete success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("delete fail");
                return ResponseEntity.ok(result);
            }
        }else {
            result.setMsg("customer does not exsits");
            return ResponseEntity.ok(result);
        }
    }



    @RequestMapping(value="/deleteAllCustomers", method=RequestMethod.DELETE)
    public ResponseEntity deleteAllCustomers(){
        AjaxResponse result = new AjaxResponse();
        this.customersService.deleteAllCustomers();
        result.setMsg("delete all customers");
        return ResponseEntity.ok(result);

    }


    @RequestMapping(value="/updateCustomers", method=RequestMethod.POST)
    public ResponseEntity updateCustomers(@RequestParam(value="id") String CustomerId,
                                          @RequestParam(value="password") String CPassword,
                                          @RequestParam(value="lname") String LastName,
                                          @RequestParam(value="fname") String FirstName,
                                          @RequestParam(value="phone") String PhoneNumber,
                                          @RequestParam(value="address") String Address,
                                          @RequestParam(value="email") String Email){
        AjaxResponse result = new AjaxResponse();
        CustomerId = CustomerId.substring(1);
        Customers temp = new Customers(CustomerId,CPassword,LastName,FirstName,PhoneNumber,Address,Email);
        //CustomerId = CustomerId.substring(1);

        if (!checkCustomerExistById(CustomerId)) {
                result.setMsg("customer does not exist");
                return ResponseEntity.ok(result);
            }else {
                if (this.customersService.updateCustomers(temp) > 0) {
                    result.setMsg("update success");
                    return ResponseEntity.ok(result);
                } else {
                    result.setMsg("update fail");
                    return ResponseEntity.ok(result);
                }
            }
    }



    @RequestMapping(value="/getCustomersByID", method=RequestMethod.GET)
    public ResponseEntity getCustomersByID(@RequestParam("id") String id){
        AjaxResponse result = new AjaxResponse();
        Customers temp = this.customersService.getCustomersById(id);
        if(temp == null){
            result.setMsg("customer does not exist");
            return ResponseEntity.ok(result);

        }else {
            result.setMsg("customer found");
            List l = new ArrayList();
            l.add(temp);
            result.setList(l);
            return ResponseEntity.ok(result);

        }
    }




    @RequestMapping(value="/getAllCustomers", method=RequestMethod.GET)
    public ResponseEntity getAllCustomers(){
        AjaxResponse result = new AjaxResponse();
        result.setList(this.customersService.getAllCustomers());
        result.setMsg("all customer");
        return ResponseEntity.ok(result);

    }


    @RequestMapping(value="/getUsersQuantity",method=RequestMethod.GET)
    public ResponseEntity getCustomersQuantity(){
        AjaxResponse result = new AjaxResponse();
        result.setMsg(this.customersService.getCustomersQuantity()+"");
        return ResponseEntity.ok(result);
    }


  /* @RequestMapping(value="/loginCustomer",method=RequestMethod.GET)
   public String loginCustomer(@RequestParam(value="id") String id,@RequestParam(value = "password") String pw) {

        Customers  cs = this.customersService.getCustomersById(id);
        if (cs == null){
            return "/loginfail.html";
        }else{
            if (pw.equals(cs.getCpassword())){
                return "/customerHomePage.html";

            }else {
                return "/loginfail.html";


            }
        }

    }*/
@RequestMapping(value="/loginCustomer",method=RequestMethod.POST)

public ResponseEntity loginCustomer(@RequestParam(value="id") String id,@RequestParam(value = "password") String pw) {
    AjaxResponse result = new AjaxResponse();

        Customers  cs = this.customersService.getCustomersById(id);
        if (cs == null){
            result.setMsg("loginfail.html");
            return ResponseEntity.ok(result);
        }else{
            if (pw.equals(cs.getCpassword())){
                result.setMsg("customersHomePage.html");
                return ResponseEntity.ok(result);
            }else {
                result.setMsg("loginfail.html");
                return ResponseEntity.ok(result);


            }
        }

    }
//    @RequestMapping(value="/checkCustomer",method=RequestMethod.GET)
    public boolean checkCustomer(String id,String pw) {
        Customers  cs = this.customersService.getCustomersById(id);
        if (cs == null){
            return false;
        }else{
            if (pw.equals(cs.getCpassword())){
                return true;
            }else {
                return false;
            }
        }

    }





}
