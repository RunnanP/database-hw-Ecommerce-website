package com.cse305.Controller;

import com.cse305.Entity.Item;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/item")
public class ItemController {
    @Autowired
    private ItemService itemService;

    public boolean checkItemExistById(@RequestParam("id") String id){
        if (this.itemService.getItemById(id) == null){
            return false;
        }else
            return true;

    }
    public ResponseEntity insertItem(Item item) {
        AjaxResponse result = new AjaxResponse();
        if (checkItemExistById(item.getItemID())) {
            result.setMsg("item already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.itemService.insertItem(item) > 0) {
                result.setMsg("add success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }
    }

    @RequestMapping(value = "/insertItem", method = RequestMethod.POST)
    public ResponseEntity insertItem(@RequestParam(value = "id") String ItemID, @RequestParam(value = "name") String ItemName,
                             @RequestParam(value = "quantity") int Quantity, @RequestParam(value = "price") double Price) {
        return insertItem(new Item(ItemID, ItemName, Quantity, Price));

    }

    @RequestMapping(value="/deleteItemById", method=RequestMethod.GET)
    public ResponseEntity deleteItemById(@RequestParam(value = "id", defaultValue = "") String id){
        AjaxResponse result = new AjaxResponse();
        if (checkItemExistById(id)) {
            if (this.itemService.deleteItemById(id)> 0) {
                result.setMsg("delete success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("delete fail");
                return ResponseEntity.ok(result);
            }
        }else {
            result.setMsg("item does not exsits");
            return ResponseEntity.ok(result);
        }
    }

    @RequestMapping(value="/deleteAllItem", method=RequestMethod.DELETE)
    public void deleteAllItem(){
        this.itemService.deleteAllItem();

    }


    @RequestMapping(value="/updateItem", method=RequestMethod.POST)
    public void updateItem(Item item){
        this.itemService.updateItem(item);
    }



    @RequestMapping(value="/getItemByID", method=RequestMethod.GET)
    public ResponseEntity getitemById(@PathVariable("id") String id){

        AjaxResponse result = new AjaxResponse();
        Item temp = this.itemService.getItemById(id);
        if(temp == null){
            result.setMsg("item does not exist");
            return ResponseEntity.ok(result);

        }else {
            result.setMsg("item found");
            List l = new ArrayList();
            l.add(temp);
            result.setList(l);
            return ResponseEntity.ok(result);

        }
    }




    @RequestMapping(value="/getAllItem", method=RequestMethod.GET)
    public ResponseEntity getAllItem(){
        AjaxResponse result = new AjaxResponse();
        result.setList(this.itemService.getAllItem());
        result.setMsg("all item");
        return ResponseEntity.ok(result);


    }


    @RequestMapping(value="/getItemQuantity",method=RequestMethod.GET)
    public int getItemQuantity(){
        return this.itemService.getItemQuantity();
    }
}
