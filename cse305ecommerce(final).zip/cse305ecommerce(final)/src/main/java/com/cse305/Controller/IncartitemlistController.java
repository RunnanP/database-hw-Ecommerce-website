package com.cse305.Controller;

import com.cse305.Entity.Incartitemlist;
import com.cse305.Entity.Item;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.IncartitemlistService;
import com.cse305.Service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/incartitemlist")
public class IncartitemlistController {
    @Autowired
    private IncartitemlistService incartitemlistService;
    @Autowired
    private ItemService itemService;

    public boolean checkItemExistById(String itemid, String customerId){
        if (this.incartitemlistService.getSpecificItemFromACustomerCart(itemid, customerId) == null){
            return false;
        }else
            return true;

    }
    public boolean checkItemListExistById(String customerId){
        if (this.incartitemlistService.getAllItemFromACustomerCart(customerId) == null){
            return false;
        }else
            return true;

    }

    public ResponseEntity insertItem2Cart(Item item,String customerID) {
        AjaxResponse result = new AjaxResponse();
        if (checkItemExistById(item.getItemID(),customerID)) {
            result.setMsg("item already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.incartitemlistService.insertItem2Cart(item,customerID) > 0) {
                result.setMsg("add success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }
    }

    @RequestMapping(value = "/insertItem2Cart", method = RequestMethod.POST)
    public ResponseEntity insertItem2Cart(@RequestParam(value = "id") String ItemID, @RequestParam(value = "name") String ItemName,
                                          @RequestParam(value = "quantity") int Quantity,
                                          @RequestParam(value = "price") double Price,
                                          @RequestParam(value = "customerID") String customerID) {

        return insertItem2Cart(new Item(ItemID, ItemName, Quantity, Price),customerID);


    }

    @RequestMapping(value="/deleteItemByIdAndCustomerID", method=RequestMethod.DELETE)
    public void deleteItemByIdAndCustomerID(@RequestParam(value = "id", defaultValue = "") String id,
                               @RequestParam(value = "customerID") String cusotmerID){

        this.incartitemlistService.deleteItemByIdAndCustomerID(id,cusotmerID);
    }

    @RequestMapping(value="/updateItemInCart", method=RequestMethod.POST)
    public ResponseEntity updateItem(@RequestParam(value = "itemID")String itemId,
                           @RequestParam(value = "customerID")String customerID,
                           @RequestParam(value = "change") int quantity) {
        AjaxResponse response = new AjaxResponse();
        Incartitemlist i = incartitemlistService.getSpecificItemFromACustomerCart(customerID, itemId);
        Item item = itemService.getItemById(itemId);
        //illegal item
        if (item == null) {
            response.setMsg("illegal item");
            return ResponseEntity.ok(response);
        }
        //item already in shopping cart, add or substrct by quantity
        if (i != null) {
            //add quantity
            if (quantity > 0) {
                //too many or delete
                if (quantity + i.getQuantity() > item.getQuantity()) {
                    response.setMsg("no more item available");
                    return ResponseEntity.ok(response);
                } else {
                    incartitemlistService.updateItem(new Item(itemId, item.getItemName(),
                            quantity + i.getQuantity(), item.getPrice()), customerID);
                    response.setMsg("add item sccusse");
                    return ResponseEntity.ok(response);
                }
            } else {//substract quantity
                if (quantity + i.getQuantity() <= 0) {
                    deleteItemByIdAndCustomerID(itemId, customerID);
                    response.setMsg("delete");
                    return ResponseEntity.ok(response);
                } else {
                    incartitemlistService.updateItem(new Item(itemId, item.getItemName(),
                            quantity + i.getQuantity(), item.getPrice()), customerID);
                    response.setMsg("add item sccusse");
                    return ResponseEntity.ok(response);
                }
            }


            //new item, insert if quantity is positive, igonre if quantity is negative
        } else {
            //increase
            if (quantity > 0) {
                //check available quantity
                if (quantity < item.getQuantity()) {
                    insertItem2Cart(new Item(itemId, item.getItemName(), quantity, item.getPrice()), customerID);
                    response.setMsg("add item sccusse");
                    return ResponseEntity.ok(response);

                } else { //quantity > item.getQuantity, not enough item available
                    response.setMsg("no more item available");
                    return ResponseEntity.ok(response);
                }
                //quantity <= 0, nothing  to reduce
            } else {
                response.setMsg("delete");
                return ResponseEntity.ok(response);
            }
        }
    }

    @RequestMapping(value="/deleteAllItemFromACustomerCart", method=RequestMethod.DELETE)
    public void deleteAllItemFromACustomerCart(@RequestParam(value = "customerID") String customerID ){
        this.incartitemlistService.deleteAllItemFromACustomerCart(customerID);
    }
    @RequestMapping(value="/deleteAllCart", method=RequestMethod.DELETE)
    public void deleteAllCart(){
        this.incartitemlistService.deleteAllCart();

    }

    @RequestMapping(value = "/getAllItemFromACustomerCart",method = RequestMethod.GET)
    public ResponseEntity getAllItemFromACustomerCart(@RequestParam(value = "customerID") String cusotmerID){
        AjaxResponse result = new AjaxResponse();
        if (!checkItemListExistById(cusotmerID)) {
            result.setMsg("empty");
            return ResponseEntity.ok(result);
        } else {
            result.setList(incartitemlistService.getAllItemFromACustomerCart(cusotmerID));
            result.setMsg("list");
            return ResponseEntity.ok(result);

        }

    }


    @RequestMapping(value = "/getItemQuantityACustomerCart",method = RequestMethod.GET)
    public int getItemQuantityACustomerCart(@RequestParam(value = "customerID") String cusotmerID) {
        return this.incartitemlistService.getItemQuantityACustomerCart(cusotmerID);
    }


    }
