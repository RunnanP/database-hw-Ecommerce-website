package com.cse305.Controller;


import com.cse305.Entity.*;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


@Controller
@RequestMapping("/shoppingcart")
public class ShoppingcartController {
    @Autowired
    private ShoppingcartService shoppingcartService;
    @Autowired
    private IncartitemlistService incartitemlistService;
    @Autowired
    private OrderitemlistService orderitemlistService;
    @Autowired
    private OrdersService ordersService;
    @Autowired
    private ShipmentService shipmentService;
    @Autowired
    private PaymentService paymentService;

    public boolean checkShipcartExistById(@RequestParam("id") String id){
        if (this.shoppingcartService.getShoppingcartById(id) == null){
            return false;
        }else
            return true;

    }
    public ResponseEntity insertShoppingcart(Shoppingcart shoppingcart) {
        AjaxResponse result = new AjaxResponse();
        if (checkShipcartExistById(shoppingcart.getCustomerID())) {
            result.setMsg("order already exsits");
            return ResponseEntity.ok(result);
        } else {
            if (this.shoppingcartService.insertShoppingcart(shoppingcart)> 0) {
                result.setMsg("add success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }
    }

    @RequestMapping(value = "/insertShoppingcart", method = RequestMethod.POST)
    public ResponseEntity insertShoppingcart(@RequestParam(value = "CustomerID") String customerID,
                                 @RequestParam(value = "Total") double total){
        return insertShoppingcart(new Shoppingcart(customerID, total));

    }

    @RequestMapping(value="/deleteShoppingcartById", method=RequestMethod.DELETE)
    public ResponseEntity deleteShoppingcartById(@RequestParam(value = "CustomerID") String customerID){
        AjaxResponse result = new AjaxResponse();
        if (checkShipcartExistById(customerID)) {
            if (this.shoppingcartService.deleteShoppingcartById(customerID) > 0) {
                result.setMsg("delete success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("delete fail");
                return ResponseEntity.ok(result);
            }
        }else {
            result.setMsg("order does not exsits");
            return ResponseEntity.ok(result);
        }
    }

    @RequestMapping(value="/deleteAllShoppingcart", method=RequestMethod.DELETE)
    public void deleteAllShoppingcart(){
        this.shoppingcartService.deleteAllShoppingcart();

    }

    @RequestMapping(value="/updateShoppingcart", method=RequestMethod.POST)
    public void updateShoppingcart(Shoppingcart shoppingcart){
        this.shoppingcartService.updateShoppingcart(shoppingcart);
    }

    @RequestMapping(value="/getShoppingcartById", method=RequestMethod.GET)
    public ResponseEntity getShoppingcartById(@PathVariable("CustomerID") String customerID){
        AjaxResponse result = new AjaxResponse();
        Shoppingcart temp = this.shoppingcartService.getShoppingcartById(customerID);
        if(temp == null){
            result.setMsg("shoppingcart does not exist");
            return ResponseEntity.ok(result);

        }else {
            result.setMsg("shoppingcart found");
            List l = new ArrayList();
            l.add(temp);
            result.setList(l);
            return ResponseEntity.ok(result);

        }
    }

/*    @RequestMapping(value="/getAllShoppingcart", method=RequestMethod.GET)
    public List<Shoppingcart> getAllShoppingcart(){
        return this.shoppingcartService.getAllShoppingcart();

    }

    @RequestMapping(value="/getShoppingcartQuantity",method=RequestMethod.GET)
    public int getShoppingcartQuantity(){
        return this.shoppingcartService.getShoppingcartQuantity();
    }*/


    static double taxRate = 0.08875;

    @RequestMapping(value = "/placeorder", method = RequestMethod.POST)
    public ResponseEntity placeorder(
                         @RequestParam(value = "customerID") String customerID,
                         @RequestParam(value = "paymentID")String paymentID,
                         @RequestParam(value = "trackingNumber")String trackingNumber){
        AjaxResponse response = new AjaxResponse();

        List<Incartitemlist> itemsInCart = this.incartitemlistService.getAllItemFromACustomerCart(customerID);
        Iterator it = itemsInCart.iterator();
        String orderID = ordersService.generate_orderID();


        double totalprice=shoppingcartService.getShoppingTotalPriceByCustomerID(customerID);
        
        if (totalprice<=0){
            response.setMsg("fail");
            return ResponseEntity.ok(response);
        }
        Orders order=new Orders(orderID,customerID,paymentID,trackingNumber,totalprice*taxRate,totalprice*(1+taxRate));
        this.ordersService.insertOrder(order);

      //  double total = 0;
        while(it.hasNext()){
            Incartitemlist item =(Incartitemlist) it.next();
            Orderitemlist orderitem = new Orderitemlist(orderID, item.getItemID(), item.getItemName(), item.getQuantity(), item.getUnitPrice(),item.getSubtotal());

           // double totalprice=shoppingcartService.getShoppingTotalPriceByCustomerID(customerID);
          //  Orders order=new Orders(orderID,customerID,paymentID,trackingNumber,totalprice*taxRate,totalprice*(1+taxRate));
          //  this.ordersService.insertOrder(order);
            this.orderitemlistService.insertOrderitemlist(orderitem);
       //     total += orderitem.getSubtotal();
        }
        this.incartitemlistService.deleteAllItemFromACustomerCart(customerID);
      //  double tax = Math.floor(total * taxRate * 100) / 100;
       // Orders o = new Orders(orderID, customerID, paymentID, trackingNumber, tax, (total + tax));
        //this.ordersService.insertOrder(o);
    /*   if(this.ordersService.insertOrder(o)>0){
            response.setMsg("success");
            ArrayList a = new ArrayList();
            a.add(o);
            response.setList(a);
            return ResponseEntity.ok(response);
        }else {
            response.setMsg("fail");
            return ResponseEntity.ok(response);


        }*/

        if(order!=null){
            response.setMsg("success");
            ArrayList a = new ArrayList();
           // a.add(o);
            a.add(order);
            response.setList(a);
            return ResponseEntity.ok(response);
        }else {
            response.setMsg("fail");
            return ResponseEntity.ok(response);


        }



    }
}
