package com.cse305.Controller;

import com.cse305.Entity.Orderitemlist;
import com.cse305.Response.AjaxResponse;
import com.cse305.Service.OrderitemlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.xml.ws.Response;
import java.util.List;

@Controller
@RequestMapping("/orderitemlistController")
public class OrderitemlistController {
    @Autowired
    private OrderitemlistService orderitemlistService;

    public boolean checkItemExistById(String orderId,String itemId){
        if (this.orderitemlistService.getOrderitemlistByOrderIdAndItemId(orderId,itemId) == null){
            return false;
        }else
            return true;

    }
    public boolean checkOrderIDExsit(String orderId){
        if (this.orderitemlistService.getOrderitemlistByOrderId(orderId) == null){
            return false;
        }else
            return true;

    }
    public ResponseEntity insertOrderitemlist(Orderitemlist orderitemlist) {
        AjaxResponse result = new AjaxResponse();
        if (checkItemExistById(orderitemlist.getOrderID(),orderitemlist.getItemID())) {
            result.setMsg("item already exsits in order"+orderitemlist.getOrderID());
            return ResponseEntity.ok(result);
        } else {
            if (this.orderitemlistService.insertOrderitemlist(orderitemlist)> 0) {
                result.setMsg("add success");
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("add fail");
                return ResponseEntity.ok(result);
            }
        }
    }

    @RequestMapping(value = "/insertOrderitemlist", method = RequestMethod.POST)
    public ResponseEntity insertOrderitemlist(@RequestParam(value = "orderID") String orderID,
                                      @RequestParam(value = "itemID") String itemID,
                                      @RequestParam(value = "itemName") String itemName,
                                      @RequestParam(value = "itemNumber") int itemNumber,
                                      @RequestParam(value = "unitPrice") Double unitPrice,
                                              @RequestParam(value = "subtotal") double subtotal) {
        // return "redirect:/index.html";
        return insertOrderitemlist(new Orderitemlist(orderID, itemID, itemName, itemNumber,unitPrice,subtotal));

    }

    @RequestMapping(value="/deleteAllItemFromACustomerCart", method=RequestMethod.DELETE)
    public void deleteAllItemFromACustomerCart(@RequestParam(value = "id", defaultValue = "") String id){

    }

    @RequestMapping(value="/deleteAllOrderitemlist", method=RequestMethod.DELETE)
    public void deleteAllOrderitemlist(){
        this.orderitemlistService.deleteAllOrderitemlist();

    }


    @RequestMapping(value="/updateOrderitemlist", method=RequestMethod.POST)
    public void updateOrderitemlist(Orderitemlist orderitemlist){
        this.orderitemlistService.updateOrderitemlist(orderitemlist);
    }



    @RequestMapping(value="/getOrderitemlistByOrderId", method=RequestMethod.GET)
    public ResponseEntity getOrderitemlistByOrderId(@RequestParam("id") String id){
        AjaxResponse result = new AjaxResponse();
        if (checkOrderIDExsit(id)) {
            result.setMsg("order does not exist");
            return ResponseEntity.ok(result);
        } else {
            if (this.orderitemlistService.getOrderitemlistByOrderId(id).size()!=0) {
                result.setMsg("all items");
                result.setList(this.orderitemlistService.getOrderitemlistByOrderId(id));
                return ResponseEntity.ok(result);
            } else {
                result.setMsg("no item");
                return ResponseEntity.ok(result);
            }
        }
    }




/*    @RequestMapping(value="/getAllOrderitemlist", method=RequestMethod.GET)
    public List<Orderitemlist> getAllOrderitemlist(){
        return this.orderitemlistService.getAllOrderitemlist();


    }*/


    @RequestMapping(value="/getOrderitemlistQuantityByOrderId",method=RequestMethod.GET)
    public int getOrderitemlistQuantityByOrderId(String id){
        return this.orderitemlistService.getOrderitemlistQuantityByOrderId(id);
    }
}
