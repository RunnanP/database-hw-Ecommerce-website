package com.cse305.Response;

import com.cse305.Entity.Customers;

import java.util.List;

public class AjaxResponse {

    String msg;

    public AjaxResponse(String msg) {
        this.msg = msg;
    }

    public List<?> getList() {
        return list;
    }

    public void setList(List<?> list) {
        this.list = list;
    }

    List<?> list;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public AjaxResponse() {
    }
}
