package com.cse305.Entity;

public class Orders {

    private String orderID;
    private String customerID;
    private String paymentID;
    private String trackingNumber;
    private double tax;
    private double totalPrice;

    public Orders() {
    }

    public Orders(String orderID, String customerID, String paymentID, String trackingNumber, double tax, double totalPrice) {
        this.orderID = orderID;
        this.customerID = customerID;
        this.paymentID = paymentID;
        this.trackingNumber = trackingNumber;
        this.tax = tax;
        this.totalPrice = totalPrice;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }


}
