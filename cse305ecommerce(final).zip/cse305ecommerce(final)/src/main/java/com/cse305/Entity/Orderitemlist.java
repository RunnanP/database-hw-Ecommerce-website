package com.cse305.Entity;

public class Orderitemlist {

    private String orderID;
    private String itemID;
    private String itemName;
    private int itemNumber;
    private double unitPrice;
    private double subtotal;

    public Orderitemlist() {
    }

    public Orderitemlist(String orderID, String itemID, String itemName, int itemNumber, double unitPrice, double subtotal) {
        this.orderID = orderID;
        this.itemID = itemID;
        this.itemName = itemName;
        this.itemNumber = itemNumber;
        this.unitPrice = unitPrice;
        this.subtotal = subtotal;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(int itemNumber) {
        this.itemNumber = itemNumber;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }
}
