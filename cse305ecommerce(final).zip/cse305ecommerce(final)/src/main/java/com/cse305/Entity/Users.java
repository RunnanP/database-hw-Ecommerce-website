package com.cse305.Entity;

import javax.persistence.*;
import java.io.Serializable;


//@Entity
//@Table(name="users")
public class Users implements Serializable {

  //  @Id
  //  @Column(name="UserID")
  //  @GeneratedValue
    private String userId;

   // @Column(name="Role")
    private String role;


    public Users(String userId,String role){
        this.userId=userId;
        this.role=role;
    }
    public Users(){
        this.userId=null;
        this.role=null;
    }
    public String getUserId() {
        return userId;
    }



    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }




}
