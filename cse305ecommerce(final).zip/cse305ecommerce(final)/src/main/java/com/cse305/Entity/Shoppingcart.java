package com.cse305.Entity;

public class Shoppingcart {
    private String customerID;
    private double total;

    public Shoppingcart() {
    }

    public Shoppingcart(String customerID, double total) {
        this.customerID = customerID;
        this.total = total;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
