package com.cse305.Entity;

public class Employee {

    private String employeeId;
    private String epassword;
    private String lName;
    private String fName;
    private String phoneNumber;
    private String address;
    private String email;


    public Employee() {
    }

    public Employee(String employeeId, String epassword, String lName, String fName, String phoneNumber, String address, String email){
        this.employeeId=employeeId;
        this.epassword=epassword;
        this.lName=lName;
        this.fName=fName;
        this.phoneNumber=phoneNumber;
        this.address=address;
        this.email=email;
    }
    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEPassword() {
        return epassword;
    }

    public void setEPassword(String epassword) {
        this.epassword = epassword;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
