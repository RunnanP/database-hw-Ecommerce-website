package com.cse305.Entity;

public class Payment {

    private String paymentID;
    private String cardNumber;
    private String paymentType;

    public Payment() {
    }

    public Payment(String paymentID, String cardNumber, String paymentType) {
        this.paymentID = paymentID;
        this.cardNumber = cardNumber;
        this.paymentType = paymentType;
    }

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }
}
