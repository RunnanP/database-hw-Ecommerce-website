package com.cse305.Entity;

public class Shipment {

    private String trackingNumber;
    private String address;
    private double shipmentCharge;
    private String typeOfShipment;

    public Shipment() {
    }

    public Shipment(String trackingNumber, String address, double shipmentCharge, String typeOfShipment) {
        this.trackingNumber = trackingNumber;
        this.address = address;
        this.shipmentCharge = shipmentCharge;
        this.typeOfShipment = typeOfShipment;
    }

    public String getTrackingNumber() {
        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getShipmentCharge() {
        return shipmentCharge;
    }

    public void setShipmentCharge(double shipmentCharge) {
        this.shipmentCharge = shipmentCharge;
    }

    public String getTypeOfShipment() {
        return typeOfShipment;
    }

    public void setTypeOfShipment(String typeOfShipment) {
        this.typeOfShipment = typeOfShipment;
    }
}
